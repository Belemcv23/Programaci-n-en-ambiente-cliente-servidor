const express = require('express');
const cors = require('cors');

const env = require('./config/environment');

class App {
    constructor() {
        this.app = express();
        this.port = env.port;
        this.middlewares();
        this.routes();
    }

    middlewares() {
        this.app.use(cors());
       
        this.app.use(express.json());

    }

    start() {
        this.app.listen(this.port, () => {
            console.log(`Servidor esta ejecutando en el puerto ${this.port}`);
        });
    }

    routes() {

        this.app.get('/', (req, res) => {
            res.send('Hola Mundo!');
        });

        this.app.use('/user', require('./routes/user'));
        this.app.use('/pokemon', require('./routes/pokemon'));
        this.app.use('/game', require('./routes/game'));
    }

}
module.exports = App;  